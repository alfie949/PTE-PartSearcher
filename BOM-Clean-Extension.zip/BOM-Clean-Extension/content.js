//Finds and highlights the search term found in storage
function highlightTerm(term) {
  if (!term) return;

  const escapedTerm = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(escapedTerm, 'gi');
  let matchCount = 0;

  const elements = document.body.querySelectorAll('*:not(script):not(style):not(mark):not(noscript)');

  elements.forEach(el => {
    for (const node of el.childNodes) {
      if (node.nodeType === Node.TEXT_NODE && node.nodeValue.trim()) {
        const matches = node.nodeValue.match(regex);
        if (matches) {
          matchCount += matches.length;

          const span = document.createElement('span');
          span.innerHTML = node.nodeValue.replace(regex, match => `<mark>${match}</mark>`);
          el.replaceChild(span, node);
        }
      }
    }
  });

  // Update the tab title with the match count
  if (matchCount > 0) {
    const originalTitle = document.title.replace(/\s\(\d+\)$/, ''); // Remove previous count if any
    document.title = `(${matchCount}) ${originalTitle}`;
  }
}

// Run highlighting after the DOM is ready
if (typeof chrome !== "undefined" && chrome.storage) {
  chrome.storage.local.get('searchTerm', ({ searchTerm }) => {
    if (searchTerm) highlightTerm(searchTerm);
  });
}

//Bridge between webpage and extension
window.addEventListener("message", (event) => {
  if (event.source !== window) return;

  const message = event.data;
  if (!message || !message.fromPage) return;

  chrome.runtime.sendMessage(message, (response) => {
    // Optionally send response back to page
    window.postMessage({ fromExtension: true, type: message.type, response }, "*");
  });
});
