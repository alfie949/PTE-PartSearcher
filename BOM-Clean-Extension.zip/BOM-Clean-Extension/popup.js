const siteListElement = document.getElementById('siteList');
const newSiteInput = document.getElementById('newSiteInput');

//Get the sites list and populate the extension with site list and remove buttons
function loadSites() {
  chrome.storage.local.get({ searchSites: [] }, ({ searchSites }) => {
    siteListElement.innerHTML = '';
    searchSites.forEach((site, index) => {
      const li = document.createElement('li');

      const siteText = document.createElement('div');
      siteText.textContent = site;
      siteText.className = 'site-url';

      const removeBtn = document.createElement('button');
      const siteName = (new URL(site).hostname).split(".")[1];
      const siteNameCapitalised = String(siteName).charAt(0).toUpperCase() + String(siteName).slice(1);
      removeBtn.textContent = `🗑️ Remove ${siteNameCapitalised} ...`;
      removeBtn.onclick = () => {
        searchSites.splice(index, 1);
        chrome.storage.local.set({ searchSites }, loadSites);
      };

      li.appendChild(siteText);
      li.appendChild(removeBtn);
      siteListElement.appendChild(li);
    });
  });
}

//Add sites to the list
document.getElementById('addSiteButton').addEventListener('click', () => {
  const newSite = newSiteInput.value.trim();
  if (!newSite) return;

  chrome.storage.local.get({ searchSites: [] }, ({ searchSites }) => {
    if (!searchSites.includes(newSite)) {
      searchSites.push(newSite);
      chrome.storage.local.set({ searchSites }, () => {
        newSiteInput.value = '';
        loadSites();
      });
    }
  });
});

//search when the search button is clicked
document.getElementById('searchButton').addEventListener('click', () => {
  const term = document.getElementById('searchInput').value.trim();
  if (term) {
    chrome.runtime.sendMessage({ type: 'BOMCLEANSEARCH', term });
  }
});

loadSites();

//highlight search when the extension loads
document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('searchInput');
  searchInput.focus();
  searchInput.select();
});

//onclick for the search button
document.getElementById('searchInput').addEventListener('click', (e) => {
  e.target.select();
});

//if we hit enter, search
document.getElementById('searchInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault(); // Optional: prevent form submission or popup closing
    document.getElementById('searchButton').click(); // Trigger search
  }
});

