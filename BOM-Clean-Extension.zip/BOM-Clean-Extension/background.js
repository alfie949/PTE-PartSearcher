chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'BOMCLEANSEARCH') {
    const { term } = message;

    chrome.storage.local.get({ searchSites: [] }, async ({ searchSites }) => {
      for (const baseUrl of searchSites) {
        const fullUrl = baseUrl + encodeURIComponent(term);
        const tabs = await chrome.tabs.query({});
        const siteName = (new URL(baseUrl).hostname).split(".")[1];
        const existingTab = tabs.find(tab => tab.url && tab.url.includes(siteName));

        if (existingTab) {
          chrome.tabs.update(existingTab.id, { url: fullUrl, active: false });
        } else {
          chrome.tabs.create({ url: fullUrl, active: false });
        }
      }

      chrome.storage.local.set({ searchTerm: term });
      sendResponse({ status: `Updated extension search to "${term}" your tabs should now be (re-)loading` });
    });

    return true; // Keep sendResponse alive for async
  }

  if (message.type === 'BOM_GET_SITES') {
    chrome.storage.local.get({ searchSites: [] }, ({ searchSites }) => {
      sendResponse({ sites: searchSites });
    });
    return true;
  }

  if (message.type === 'BOM_SET_SITES') {
    chrome.storage.local.set({ searchSites: message.sites }, () => {
      sendResponse({ status: 'saved' });
    });
    return true;
  }
});

//Create the context menu button on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "multiSiteSearch",
    title: "Search BOM sites for \"%s\"",
    contexts: ["selection"]
  });
});

//Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "multiSiteSearch") {
    const term = info.selectionText?.trim();
    if (!term) return;

    // Reuse your existing SEARCH logic
    chrome.storage.local.get({ searchSites: [] }, async ({ searchSites }) => {
      for (const baseUrl of searchSites) {
        const fullUrl = baseUrl + encodeURIComponent(term);
        const tabs = await chrome.tabs.query({});
		const siteName = (new URL(baseUrl).hostname).split(".")[1];
        const existingTab = tabs.find(tab => tab.url && tab.url.includes(siteName));

        if (existingTab) {
          chrome.tabs.update(existingTab.id, { url: fullUrl, active: false });
        } else {
          chrome.tabs.create({ url: fullUrl, active: false });
        }
      }

      chrome.storage.local.set({ searchTerm: term });
    });
  }
});

